TODO
----
COSBench is an ongoing project, in next six months, we plan to make below improvements:

1. more storage interface support, list is TBD.


If you have any other suggestions or you want to work with us together. please contact us at yaguang.wang@intel.com.


== END ==
